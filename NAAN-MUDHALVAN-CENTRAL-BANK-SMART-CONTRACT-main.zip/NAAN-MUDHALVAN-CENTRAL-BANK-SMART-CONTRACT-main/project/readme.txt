1.install metamask
2.run the following commands in the project directory
  npm install
  npm install bootstarp
  npm start
